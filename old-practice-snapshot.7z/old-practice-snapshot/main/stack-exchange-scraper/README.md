# &ldquo;Stack Exchange Scraper&rdquo;

This is not an actual Stack Exchange scraper program. Rather, these are
solutions to the HackerRank exercise [Build a Stack Exchange
Scraper](https://www.hackerrank.com/challenges/stack-exchange-scraper).
