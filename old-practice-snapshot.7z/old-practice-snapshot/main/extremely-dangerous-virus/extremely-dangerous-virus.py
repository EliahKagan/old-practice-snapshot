a, b, t = map(int, raw_input().split())
print pow((a + b) / 2, t, 1000000007)
