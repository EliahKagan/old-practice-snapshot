#ifndef MINIMUM_SPANNING_TREE_G4G_KRUSKAL_H_
#define MINIMUM_SPANNING_TREE_G4G_KRUSKAL_H_

#include <functional>
#include <iostream>
#include <queue>
#include <utility>
#include <vector>

#endif // ! MINIMUM_SPANNING_TREE_G4G_KRUSKAL_H_
