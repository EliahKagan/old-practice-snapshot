#ifndef MINIMUM_SPANNING_TREE_G4G_PRIM_H_
#define MINIMUM_SPANNING_TREE_G4G_PRIM_H_

#include <cstddef>
#include <iostream>
#include <limits>
#include <tuple>
#include <unordered_map>
#include <utility>
#include <vector>

#endif // ! MINIMUM_SPANNING_TREE_G4G_PRIM_H_
