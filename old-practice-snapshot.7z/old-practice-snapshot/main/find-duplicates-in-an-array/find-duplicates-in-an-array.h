#pragma once
#ifndef FIND_DUPLICATES_IN_AN_ARRAY_H_
#define FIND_DUPLICATES_IN_AN_ARRAY_H_

#include <iostream>
#include <vector>

#endif // ! FIND_DUPLICATES_IN_AN_ARRAY_H_
