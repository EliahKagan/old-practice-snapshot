See also `../union-find`.
