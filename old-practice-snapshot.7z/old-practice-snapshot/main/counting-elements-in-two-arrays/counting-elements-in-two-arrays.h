#pragma once
#ifndef COUNTING_ELEMENTS_IN_TWO_ARRAYS_H_
#define COUNTING_ELEMENTS_IN_TWO_ARRAYS_H_

#include <cassert>
#include <algorithm>
#include <iostream>
#include <vector>

#endif // ! COUNTING_ELEMENTS_IN_TWO_ARRAYS_H_
