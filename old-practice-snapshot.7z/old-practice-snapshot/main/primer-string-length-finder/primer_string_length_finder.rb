def length_finder(input_array)
  input_array.map(&:length)
end
