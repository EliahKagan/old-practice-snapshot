#pragma once
#ifndef CLONE_A_BINARY_TREE_H_
#define CLONE_A_BINARY_TREE_H_

#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif

#include <ciso646>
#include <cstddef>
#include <iostream>
#include <map>
#include <unordered_map>

#endif // ! CLONE_A_BINARY_TREE_H_
