#pragma once
#ifndef BIPARTITE_GRAPH_G4G_H_
#define BIPARTITE_GRAPH_G4G_H_

#include <array>
#include <cassert>
#include <cstring>
#include <iostream>
#include <queue>
#include <stdexcept>

#endif // ! BIPARTITE_GRAPH_G4G_H_
