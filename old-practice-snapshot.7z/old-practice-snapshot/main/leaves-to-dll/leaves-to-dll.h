#pragma once
#ifndef LEAVES_TO_DLL_
#define LEAVES_TO_DLL_

#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif

#include <cstdio>
#include <cstdlib>
#include <iostream>

#endif // ! LEAVES_TO_DLL_
