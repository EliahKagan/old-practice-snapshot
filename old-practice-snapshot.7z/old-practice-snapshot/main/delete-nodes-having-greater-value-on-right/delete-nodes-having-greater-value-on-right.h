#pragma once

#ifndef DELETE_NODES_HAVING_GREATER_VALUE_ON_RIGHT_H_
#define DELETE_NODES_HAVING_GREATER_VALUE_ON_RIGHT_H_

#include <cstddef>
#include <iostream>
#include <vector>

#endif // ! DELETE_NODES_HAVING_GREATER_VALUE_ON_RIGHT_H_
