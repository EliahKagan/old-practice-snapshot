#include <iostream>

int main()
{
    int a, b, c;
    if (std::cin >> a >> b >> c) std::cout << a + b + c << '\n';
}
