# Heapsort

Heapsort (and tests), implemented in a few languages.

This was for personal practice, not involving any website / online judge.

See also `../mergesort`, `../qs`, and `../sorting`.
