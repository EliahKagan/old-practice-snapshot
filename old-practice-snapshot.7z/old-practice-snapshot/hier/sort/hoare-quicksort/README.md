# Hoare quicksort

Quicksort with the Hoare (rather than Lomuto) partitioning scheme, with tests.

This was for personal practice, not involving any website / online judge.
