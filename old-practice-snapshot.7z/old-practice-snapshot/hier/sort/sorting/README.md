# Sorting

Recursive functional (non in-place, non-mutating) quicksort-like sorts, in C#
and F#.

This was for personal practice, not involving any website / online judge.

See also `../heapsort`, `../mergesort`, and `../qs`.
