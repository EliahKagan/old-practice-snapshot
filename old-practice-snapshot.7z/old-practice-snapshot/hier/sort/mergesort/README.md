# Mergesort

Mergesort (and tests) in C#.

This was for personal practice, not involving any website / online judge.

See also `../heapasort`, `../qs`, and `../sorting`.
