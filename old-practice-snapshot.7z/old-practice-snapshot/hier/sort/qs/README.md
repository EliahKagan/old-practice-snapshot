# Quicksort in Python

This was for personal practice, not involving any website / online judge.

This is just a module with methods for Quicksort with Lomuto and Hoare
partitioning. It doesn't supply a calling program or unit tests.

See also `../heapsort`, `../mergesort`, and `../sorting`.
