# &ldquo;Llama book&rdquo; exercises

These are my solutions to exercises in *Learning Perl* by Randal L. Schwartz,
brian d foy, and Tom Phoenix (known as the &ldquo;llama book&rdquo;) and
directly related problems.
