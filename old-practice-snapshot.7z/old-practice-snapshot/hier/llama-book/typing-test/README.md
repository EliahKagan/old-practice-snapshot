# Typing Test

Spiffier version of the "typing test" exercise.
